"""Reproducible one-service check; each invocation keeps every attempted result."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
import urllib.request

p = argparse.ArgumentParser()
p.add_argument('--name', required=True)
p.add_argument('--backend', choices=['native', 'nvlink'], required=True)
p.add_argument('--seeds', type=int, nargs='+', default=[42])
p.add_argument('--capacity', type=int, default=512)
p.add_argument('--memory', default='0.85')
args = p.parse_args()
base = Path('/tmp/megaflux-results/nvlink-metadata-20261027')
root = base / args.name
root.mkdir(exist_ok=False)
repo = Path('/root/flashinfer')
env = dict(os.environ)
for key in list(env):
    if key.startswith('MEGAFLUX_') or key in ('LD_PRELOAD', 'CUDA_LAUNCH_BLOCKING', 'NCCL_GRAPH_REGISTER'):
        env.pop(key)
env.update(PYTHONPATH='/root/flashinfer:/tmp/megaflux-deps', VLLM_ENGINE_READY_TIMEOUT_S='1800',
           NVSHMEM_DISABLE_CUDA_VMM='1', NVSHMEM_SYMMETRIC_SIZE='16G',
           FLASHINFER_MOE_EP_MEGAFLUX_CUDA_GRAPH='1',
           FLASHINFER_MOE_EP_MEGAFLUX_METADATA='nvlink',
           FLASHINFER_MOE_EP_MEGAFLUX_MIN_REPLICA_ROUTES='12289',
           FLASHINFER_MOE_EP_MEGAFLUX_ADMISSION='1', NCCL_GRAPH_MIXING_SUPPORT='1')
server = None
done = threading.Event()


def state(stage, **data):
    data = dict(stage=stage, time=time.time(), **data)
    (root / 'status.json').write_text(json.dumps(data, indent=2))
    with (root / 'events.jsonl').open('a') as f:
        f.write(json.dumps(data) + '\n')
    print(json.dumps(data), flush=True)


def telemetry():
    while not done.wait(10):
        with (root / 'telemetry.csv').open('a') as f:
            f.write('# ' + str(time.time()) + '\n')
            f.flush()
            subprocess.run(['nvidia-smi', '--query-gpu=index,memory.used,utilization.gpu,temperature.gpu,clocks.sm,power.draw', '--format=csv,noheader'], stdout=f)


def execute(name, command):
    (root / (name + '.command.json')).write_text(json.dumps(command, indent=2))
    state(name)
    with (root / (name + '.log')).open('w') as f:
        result = subprocess.run(command, cwd=repo, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=1800)
    if result.returncode:
        raise RuntimeError(f'{name} exit {result.returncode}')


def benchmark(seed, prewarm=False):
    for length, concurrency, count in [(4096, 64, 128), (7168, 128, 256)]:
        output = 8 if prewarm else 64
        count = concurrency if prewarm else count
        name = f'{"prewarm" if prewarm else "traffic"}-{length}-c{concurrency}-s{seed}'
        command = ['vllm', 'bench', 'serve', '--backend', 'vllm', '--base-url', 'http://127.0.0.1:8000',
                   '--endpoint', '/v1/completions', '--model', '/gpfs/rd/models/DeepSeek-V4.1-Flash-1017/',
                   '--served-model-name', 'deepseek-v41-megaflux', '--tokenizer-mode', 'deepseek_v41',
                   '--dataset-name', 'random', '--random-input-len', str(length), '--random-output-len', str(output),
                   '--random-range-ratio', '0', '--num-prompts', str(count), '--max-concurrency', str(concurrency),
                   '--num-warmups', '4', '--ignore-eos', '--seed', str(seed), '--temperature', '0',
                   '--save-result', '--save-detailed', '--result-dir', str(root), '--result-filename', name + '.json',
                   '--percentile-metrics', 'ttft,tpot,itl,e2el', '--metric-percentiles', '50,95,99', '--disable-tqdm']
        execute(name, command)
        data = json.loads((root / (name + '.json')).read_text())
        audit = dict(completed=data['completed'], failed=data['failed'],
                     complete_inputs=sum(n == length for n in data['input_lens']),
                     complete_outputs=sum(n == output for n in data['output_lens']), expected=count)
        (root / (name + '.audit.json')).write_text(json.dumps(audit, indent=2))
        if audit != dict(completed=count, failed=0, complete_inputs=count, complete_outputs=count, expected=count):
            raise RuntimeError(f'invalid workload: {name}: {audit}')
        state('case_passed', name=name, **audit, **{k: data.get(k) for k in ('duration', 'output_throughput', 'p95_ttft_ms', 'p95_tpot_ms')})


try:
    active = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    if active:
        raise RuntimeError('GPUs have active processes; no service started')
    free = [int(x) for x in subprocess.check_output(['nvidia-smi', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).splitlines()]
    if len(free) != 8 or min(free) < 130000:
        raise RuntimeError('insufficient free GPU memory; no service started')
    # Record all maintained MegaFlux implementation files and the patched adapter.
    paths = list((repo / 'flashinfer/moe_ep/cute_dsl/megamoe/megaflux_sm90').glob('*.py'))
    paths += list((repo / 'flashinfer/moe_ep/cute_dsl/megamoe/megaflux_sm90').glob('*.cu'))
    paths += list((repo / 'flashinfer/moe_ep/backends/mega/kernel/sm90').glob('*megaflux*/*.py'))
    paths += [repo / 'flashinfer/moe_ep/megaflux_plan.py', Path('/usr/local/lib/python3.12/dist-packages/vllm/model_executor/layers/fused_moe/flashinfer_moe_ep.py')]
    hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    (root / 'source-sha256.json').write_text(json.dumps(hashes, indent=2))
    for path in paths:
        snapshot = root / 'source-snapshot' / str(path).lstrip('/')
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(path.read_bytes())
    command = ['vllm', 'serve', '/gpfs/rd/models/DeepSeek-V4.1-Flash-1017/',
               '--tensor-parallel-size', '1', '--data-parallel-size', '8', '--data-parallel-size-local', '8',
               '--enable-expert-parallel', '--gpu-memory-utilization', args.memory, '--enforce-eager',
               '--trust-remote-code', '--max-model-len', '8192', '--max-num-batched-tokens', str(args.capacity),
               '--max-num-seqs', '32', '--served-model-name', 'deepseek-v41-megaflux', '--reasoning-parser', 'deepseek_v41']
    if args.backend == 'nvlink':
        command += ['--kernel-config', '{"moe_backend":"flashinfer_moe_ep_megaflux_sm90"}']
    (root / 'server.command.json').write_text(json.dumps(command, indent=2))
    (root / 'server.env.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('NVSHMEM_', 'NCCL_', 'FLASHINFER_', 'VLLM_')) or k == 'PYTHONPATH'}, indent=2))
    with (root / 'server.log').open('w') as log:
        server = subprocess.Popen(command, cwd=repo, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (root / 'server.pid').write_text(str(server.pid))
    state('starting', pid=server.pid)
    threading.Thread(target=telemetry, daemon=True).start()
    for _ in range(360):
        if server.poll() is not None:
            raise RuntimeError(f'server exited {server.returncode}')
        try:
            urllib.request.urlopen('http://127.0.0.1:8000/health', timeout=2).close()
            break
        except Exception:
            time.sleep(5)
    else:
        raise RuntimeError('service readiness timeout')
    execute('correctness', ['python3', 'examples/deepseek_v41/verify_vllm_megaflux_sm90.py', '--output', str(root / 'correctness.json')])
    benchmark(1042, prewarm=True)
    for seed in args.seeds:
        benchmark(seed)
    assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest for path,digest in hashes.items())
    state('ALL_DONE')
except BaseException as exc:
    state('FAILED', error=repr(exc))
    raise
finally:
    done.set()
    if server is not None:
        # Only the process group created by this invocation is stopped.
        try:
            os.killpg(server.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            server.wait(timeout=40)
        except subprocess.TimeoutExpired:
            os.killpg(server.pid, signal.SIGKILL)
            server.wait(timeout=20)
