import os,json,time
from pathlib import Path
import torch
import torch.distributed as dist
inference_guard = torch.inference_mode()
inference_guard.__enter__()
from flashinfer.moe_ep import BootstrapConfig,FleetParams,MegaConfig,MoEEpLayer,MoEEpTensors,bootstrap_moe_ep_runtime,ensure_moe_ep_cuda_device,finalize_moe_ep_runtime
from flashinfer.moe_ep.backends.mega.kernel.sm90.fp8_mxfp4_bf16_megaflux_graph import Sm90_Mxfp4_MegaFluxGraphConfig
from flashinfer.moe_ep.backends.mega.kernel.sm90.fp8_mxfp4_bf16_pull_cutedsl.tuner import create_tuning_weights
from flashinfer.moe_ep.core.kernel.registry import create_mega_kernel
from flashinfer.moe_ep.megaflux_plan import PlanConfig
from flashinfer.moe_ep.cute_dsl.megamoe.megaflux_sm90.benefit import ReplicaAdmission
from flashinfer.moe_ep.cute_dsl.megamoe.megaflux_sm90.replay import MegaFluxGraphReplay
root=Path('/tmp/megaflux-results/long-context-20261027');root.mkdir(exist_ok=True)
rank=int(os.environ['RANK']);world=int(os.environ['WORLD_SIZE']);local=int(os.environ['LOCAL_RANK']);device=torch.device('cuda',local)
b=BootstrapConfig(world_size=world,rank=rank,device=local);ensure_moe_ep_cuda_device(b)
common=dict(intermediate_size=2304,top_k=6,gate_up_clamp=10.,load_balance_mode='static',selective_weight_copy=True,metadata_transport='nvlink',min_replica_routes=49)
cfg=Sm90_Mxfp4_MegaFluxGraphConfig(**common,plan_config=PlanConfig(384,world,1,512,6))
runtime=bootstrap_moe_ep_runtime(b,create_mega_kernel(cfg).runtime_requirements(b))
g=torch.Generator(device=device).manual_seed(42+rank)
h=torch.randn(1024,5120,dtype=torch.bfloat16,device=device,generator=g)
ids=torch.stack([torch.randperm(384,device=device,generator=g)[:6] for _ in range(1024)]).long()
w=torch.softmax(torch.randn(1024,6,device=device,generator=g),-1)

from flashinfer.moe_ep.cute_dsl.megamoe.megaflux_sm90.benefit import ReplicaAdmission
common.update(min_replica_routes=12289,replica_admission=ReplicaAdmission(3000,8000,3300000,100004,300000))
layer=None;replays=[];layers=[];raw_weights=[];snapshots=[]
try:
 other=dist.new_group(backend='nccl')
 sync=torch.ones(1,device=device)
 hotspot=torch.arange(6,device=device).expand(512,-1).contiguous()
 for index in range(int(os.environ.get('MEGAFLUX_STRESS_LAYERS','40'))):
  raw=create_tuning_weights(local_experts=48,hidden=5120,intermediate=2304,rank=rank,device=device,seed=index+100)
  layer=MoEEpLayer(bootstrap=BootstrapConfig(world_size=world,rank=rank,device=local,auto_bootstrap=False),fleet_params=FleetParams(num_experts=384,max_tokens_per_rank=512,token_hidden_size=5120),weights=raw,backend=MegaConfig(megakernel=Sm90_Mxfp4_MegaFluxGraphConfig(**common,plan_config=PlanConfig(384,world,1,512,6)),quantize_input=True))
  layers.append(layer)
  replays.append(MegaFluxGraphReplay(layer,max_tokens=512,hidden_size=5120,top_k=6,device=device))
  del raw
  if rank==0:print('CAPTURED_INDEPENDENT',index,'MEMORY_MIB',torch.cuda.memory_allocated()//2**20,flush=True)
 for step in range(int(os.environ.get('MEGAFLUX_STRESS_STEPS','2000'))):
  dist.all_reduce(sync,group=other);sync.fill_(1)
  mode=step%4
  live=512 if mode in (0,3) else ([512,128,32,5,1,0][(step+rank)%6] if mode==1 else (512 if rank==step%world else 0))
  for index,replay in enumerate(replays):
   route=hotspot if mode==0 else ids
   output=replay(h[:live],route[:live],w[:live])
  if step%20==0:
   snapshots.append(output[:4].clone())
   if rank==0:print('STEP',step,'ENQUEUED',flush=True)
 torch.cuda.synchronize();dist.barrier()
 assert all(torch.isfinite(t).all().item() for t in snapshots), 'non-finite stress snapshot'
 if rank==0:print('ALL_DONE FINITE_SNAPSHOTS',len(snapshots),flush=True)
finally:
 for replay in replays:replay.close()
 for layer in reversed(layers):layer.destroy()
 finalize_moe_ep_runtime(runtime)
